"""Stage 2: ENRICH pipeline stage.
Fetches full app metadata, calculates age, tracks snapshots, and updates apps table.
Prioritizes new releases and movers, respects enrich caps, and computes ETA.
"""
from datetime import datetime, timezone, timedelta
import json
import logging
import time
from typing import Dict, List, Optional

from radar.db import Database
from radar.play_client import PlayClient, parse_install_bucket_midpoint, parse_date_to_iso

logger = logging.getLogger("radar.pipeline.enrich")

def get_prioritized_candidates(db: Database, run_id: str, max_age_days: int = 90) -> List[str]:
    """Retrieve app_ids to enrich for this run ordered by priority:
    1. TOP_NEW_FREE and movers_shakers
    2. TOP_GROSSING
    3. TOP_FREE and others
    Skips apps already marked is_old = 1.
    """
    query = """
    SELECT ce.app_id,
           MIN(CASE
               WHEN ce.collection IN ('topselling_new_free', 'movers_shakers') THEN 1
               WHEN ce.collection = 'topgrossing' THEN 2
               ELSE 3
           END) as priority_tier,
           MIN(ce.rank) as best_rank
    FROM chart_entries ce
    JOIN apps a ON ce.app_id = a.app_id
    WHERE ce.run_id = ?
      AND a.is_old = 0
    GROUP BY ce.app_id
    ORDER BY priority_tier ASC, best_rank ASC
    """
    with db.get_connection() as conn:
        rows = conn.execute(query, (run_id,)).fetchall()
        return [r["app_id"] for r in rows]

def run_stage_enrich(
    db: Database,
    client: PlayClient,
    run_id: str,
    settings_config: Dict,
    countries_config: Optional[Dict] = None,
    mode: str = "standard"
) -> Dict:
    today_dt = datetime.now(timezone.utc)
    today_date = today_dt.strftime("%Y-%m-%d")
    now_iso = today_dt.isoformat()
    max_age_days = settings_config.get("max_age_days", 90)

    # Locale mapping
    country_lang_map = {
        "US": "en", "GB": "en", "CA": "en", "AU": "en", "DE": "de",
        "FR": "fr", "JP": "ja", "KR": "ko", "TW": "zh_TW", "SG": "en"
    }
    if countries_config:
        for grp in ["western", "eastern"]:
            for c in countries_config.get(grp, []):
                country_lang_map[c["code"].upper()] = c.get("lang", "en")

    # Enrich cap
    caps = settings_config.get("enrich_cap", {"standard": 1500, "full": 999999})
    cap = caps.get(mode, 1500)

    all_candidates = get_prioritized_candidates(db, run_id, max_age_days)

    # Check already snapshotted in this run (resumability)
    already_done = set()
    with db.get_connection() as conn:
        rows = conn.execute(
            "SELECT app_id FROM app_snapshots WHERE run_id = ?",
            (run_id,)
        ).fetchall()
        for r in rows:
            already_done.add(r["app_id"])

    candidates_to_process = [aid for aid in all_candidates if aid not in already_done][:cap]
    total_to_process = len(candidates_to_process)

    print(f"[ENRICH] Identified {len(all_candidates)} candidates. Processing up to {total_to_process} apps (cap={cap}, mode={mode})...")

    enriched_count = 0
    skipped_old = 0
    failures = 0
    cohort_count = 0

    start_time = time.time()

    for idx, app_id in enumerate(candidates_to_process, 1):
        # Quick check if app was determined old in a previous fetch and retrieve best country
        with db.get_connection() as conn:
            app_row = conn.execute("SELECT released, first_seen_date, is_old FROM apps WHERE app_id = ?", (app_id,)).fetchone()
            if app_row and app_row["is_old"]:
                skipped_old += 1
                continue
            c_row = conn.execute(
                "SELECT country FROM chart_entries WHERE app_id = ? AND run_id = ? ORDER BY rank ASC LIMIT 1",
                (app_id, run_id)
            ).fetchone()
            c_code = (c_row["country"] if c_row else "US").upper()

        target_lang = country_lang_map.get(c_code, "en")
        target_country = c_code.lower()

        data = None
        try:
            data = client.fetch_app_details(app_id, lang=target_lang, country=target_country)
        except Exception as e:
            if target_country != "us":
                try:
                    data = client.fetch_app_details(app_id, lang="en", country="us")
                except Exception:
                    pass

        # If data was fetched but released date was None, try US store fallback or vice versa
        if data and not data.get("released"):
            if target_country != "us":
                try:
                    us_data = client.fetch_app_details(app_id, lang="en", country="us")
                    if us_data and us_data.get("released"):
                        data["released"] = us_data["released"]
                except Exception:
                    pass
            elif target_country == "us" and c_code != "US":
                try:
                    alt_data = client.fetch_app_details(app_id, lang=target_lang, country=target_country)
                    if alt_data and alt_data.get("released"):
                        data["released"] = alt_data["released"]
                except Exception:
                    pass

        if not data:
            failures += 1
            err_type = "NotFoundError"
            err_msg = f"Failed to fetch details for {app_id} in {target_country} and US"
            logger.warning(f"[ENRICH] Error fetching {app_id}: {err_msg}")
            db.log_error(run_id, "ENRICH", app_id, err_type, err_msg)
            continue
            failures += 1
            continue

        # Parse fields
        title = data.get("title")
        developer = data.get("developer")
        developer_id = data.get("developerId")
        genre = data.get("genre")
        genre_id = data.get("genreId")
        category = genre_id or genre or "GAME"
        released_raw = data.get("released")
        released_iso = parse_date_to_iso(released_raw)
        
        # Real installs vs bucket
        real_installs = data.get("realInstalls")
        installs_label = data.get("installs")
        if real_installs is None or real_installs == 0:
            parsed_val, _ = parse_install_bucket_midpoint(installs_label)
            real_installs = parsed_val

        score = data.get("score")
        ratings = data.get("ratings")
        histogram = json.dumps(data.get("histogram")) if data.get("histogram") else None
        updated = data.get("updated")
        price = data.get("price", 0.0)
        free = 1 if data.get("free", True) else 0
        contains_ads = 1 if (data.get("containsAds") or data.get("adSupported")) else 0
        offers_iap = 1 if data.get("offersIAP") else 0
        url = data.get("url") or f"https://play.google.com/store/apps/details?id={app_id}"
        icon = data.get("icon")
        summary = data.get("summary")
        description = data.get("description")

        # Age calculation
        is_old = 0
        age_estimated = 0
        if released_iso:
            try:
                rel_dt = datetime.strptime(released_iso, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                age_days = (today_dt - rel_dt).days
                if age_days > max_age_days:
                    is_old = 1
            except Exception:
                age_days = None
        else:
            age_estimated = 1
            first_seen = app_row["first_seen_date"] if (app_row and app_row["first_seen_date"]) else today_date
            try:
                fs_dt = datetime.strptime(first_seen, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                age_days = (today_dt - fs_dt).days
                if age_days > max_age_days:
                    is_old = 1
            except Exception:
                age_days = None

        if is_old:
            skipped_old += 1
        else:
            cohort_count += 1

        with db.get_connection() as conn:
            # Update apps table
            conn.execute(
                """UPDATE apps SET
                   title = ?, developer = ?, developer_id = ?, category = ?,
                   genre = ?, genre_id = ?, released = ?, age_estimated = ?,
                   is_old = ?, price = ?, free = ?, contains_ads = ?,
                   offers_iap = ?, url = ?, icon = ?, summary = ?,
                   description = ?, updated_at = ?
                   WHERE app_id = ?""",
                (
                    title, developer, developer_id, category,
                    genre, genre_id, released_iso, age_estimated,
                    is_old, price, free, contains_ads,
                    offers_iap, url, icon, summary,
                    description, now_iso, app_id
                )
            )

            # Insert snapshot
            conn.execute(
                """INSERT OR REPLACE INTO app_snapshots
                   (run_id, app_id, date, real_installs, installs_label, score,
                    ratings, histogram_json, updated, price, contains_ads, offers_iap, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    run_id, app_id, today_date, real_installs, installs_label, score,
                    ratings, histogram, updated, price, contains_ads, offers_iap, now_iso
                )
            )
            conn.commit()

        enriched_count += 1

        # Progress & ETA logging
        if idx % 10 == 0 or idx == total_to_process:
            elapsed = time.time() - start_time
            rate = enriched_count / max(elapsed, 0.1)
            remaining = total_to_process - idx
            eta_sec = remaining / max(rate, 0.01)
            eta_str = f"{int(eta_sec // 60)}m {int(eta_sec % 60)}s"
            pct = (idx / total_to_process) * 100
            print(f"[ENRICH] {idx}/{total_to_process} ({pct:.1f}%) | Age: {age_days if age_days is not None else '?'}d | Installs: {real_installs} | Old: {skipped_old} | ETA: {eta_str}")

    summary = {
        "total_candidates": len(all_candidates),
        "processed": enriched_count,
        "cohort_young_apps": cohort_count,
        "skipped_old": skipped_old,
        "failures": failures
    }
    db.set_stage_status(run_id, "ENRICH", "COMPLETED", summary)
    print(f"[ENRICH] Completed. Enriched: {enriched_count}, Young cohort: {cohort_count}, Old skipped: {skipped_old}, Failures: {failures}")
    return summary
